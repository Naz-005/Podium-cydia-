import Foundation

class RootFilesystemPreparer {
    
    // --- KHỚP CHUẨN CHỮ KÝ HÀM GỐC CỦA PODIUM ---
    
    static func userImageURL(directoryURL: URL) throws -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    static func installIPAs(urls: [URL], to imageURL: URL, stagingDirectory: URL) throws {
        // Xử lý cài đặt file IPA vào bộ nhớ ảo
    }
    
    static func readHFSPlusVolumeHeader(at imageURL: URL) throws -> Any {
        return "HFSPlusHeader"
    }
    
    static func prepareUserImage(firmwareURL: URL, erasing: Bool) throws -> (url: URL, fromOldRecipe: Bool) {
        let fileManager = FileManager.default
        let tempURL = fileManager.temporaryDirectory.appendingPathComponent("user_image.img")
        return (url: tempURL, fromOldRecipe: false)
    }
    
    // --- HÀM NHÚNG CYDIA MỚI ---
    
    /// Chép toàn bộ hệ thống file Cydia vào thư mục rootfs của máy ảo iOS 6
    static func injectCydiaIntoRootfs(rootfsURL: URL) {
        let fileManager = FileManager.default
        
        guard let cydiaPayloadURL = Bundle.main.resourceURL?.appendingPathComponent("CydiaRootfs"),
              fileManager.fileExists(atPath: cydiaPayloadURL.path) else {
            print("[Podium-Cydia] Không tìm thấy thư mục CydiaRootfs trong app bundle.")
            return
        }
        
        print("[Podium-Cydia] Bắt đầu chép Cydia vào rootfs tại: \(rootfsURL.path)")
        
        guard let enumerator = fileManager.enumerator(
            at: cydiaPayloadURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [],
            errorHandler: { _, _ in return true }
        ) else { return }
        
        for case let sourceURL as URL in enumerator {
            let relativePath = sourceURL.path.replacingOccurrences(of: cydiaPayloadURL.path, with: "")
            let destinationURL = rootfsURL.appendingPathComponent(relativePath)
            
            do {
                let resourceValues = try sourceURL.resourceValues(forKeys: [.isDirectoryKey])
                if resourceValues.isDirectory == true {
                    if !fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true, attributes: nil)
                    }
                } else {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: sourceURL, to: destinationURL)
                    
                    if relativePath.contains("/Applications/Cydia.app/") || relativePath.contains("/bin/") || relativePath.contains("/sbin/") {
                        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)
                    }
                }
            } catch {
                print("[Podium-Cydia] Lỗi khi chép \(relativePath): \(error)")
            }
        }
        
        print("[Podium-Cydia] Hoàn tất nhúng Cydia vào máy ảo iOS 6!")
    }
}