import Foundation

class RootFilesystemPreparer {
    
    static func userImageURL(in directoryURL: URL) throws -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    static func installIPAs(urls: [URL], to imageURL: URL, stagingDirectory: URL) throws {}
    
    static func readHFSPlusVolumeHeader(at imageURL: URL) throws -> Any {
        return "HFSPlusHeader"
    }
    
    // Sử dụng kiểu trả về linh hoạt hoặc generic tuple tương thích với cả bản cũ lẫn bản mới của Podium
    static func prepareUserImage(forFirmwareAt firmwareURL: URL, erasing: Bool, in directoryURL: URL) throws -> (url: URL, fromOldRecipe: Bool) {
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        return (url: tempURL, fromOldRecipe: false)
    }
    
    static func prepareUserImage(forFirmwareAt firmwareURL: URL, erasing: Bool, in directoryURL: URL) throws -> (URL, Bool) {
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        return (tempURL, false)
    }
    
    static func injectCydiaIntoRootfs(rootfsURL: URL) {
        let fileManager = FileManager.default
        
        guard let cydiaPayloadURL = Bundle.main.resourceURL?.appendingPathComponent("CydiaRootfs"),
              fileManager.fileExists(atPath: cydiaPayloadURL.path) else {
            print("[Podium-Cydia] Không tìm thấy thư mục CydiaRootfs trong app bundle.")
            return
        }
        
        print("[Podium-Cydia] Bắt đầu chép Cydia vào rootfs tại: \(rootfsURL.path)")
        
        guard let enumerator = fileManager.enumerator(
            at: cydiaPayloadURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [],
            errorHandler: { _, _ in return true }
        ) else { return }
        
        for case let sourceURL as URL in enumerator {
            let relativePath = sourceURL.path.replacingOccurrences(of: cydiaPayloadURL.path, with: "")
            let destinationURL = rootfsURL.appendingPathComponent(relativePath)
            
            do {
                let resourceValues = try sourceURL.resourceValues(forKeys: [.isDirectoryKey])
                if resourceValues.isDirectory == true {
                    if !fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true, attributes: nil)
                    }
                } else {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: sourceURL, to: destinationURL)
                    
                    if relativePath.contains("/Applications/Cydia.app/") || relativePath.contains("/bin/") || relativePath.contains("/sbin/") {
                        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)
                    }
                }
            } catch {
                print("[Podium-Cydia] Lỗi khi chép \(relativePath): \(error)")
            }
        }
        print("[Podium-Cydia] Hoàn tất nhúng Cydia vào máy ảo iOS 6!")
    }
}