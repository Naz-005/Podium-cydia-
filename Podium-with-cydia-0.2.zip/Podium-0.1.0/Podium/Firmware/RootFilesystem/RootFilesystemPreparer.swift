import Foundation

class RootFilesystemPreparer {
    
    /// Chép toàn bộ hệ thống file Cydia vào thư mục rootfs của máy ảo iOS 6
    static func injectCydiaIntoRootfs(rootfsURL: URL) {
        let fileManager = FileManager.default
        
        guard let cydiaPayloadURL = Bundle.main.resourceURL?.appendingPathComponent("CydiaRootfs"),
              fileManager.fileExists(atPath: cydiaPayloadURL.path) else {
            print("[Podium-Cydia] Không tìm thấy thư mục CydiaRootfs trong app bundle.")
            return
        }
        
        print("[Podium-Cydia] Bắt đầu chép Cydia vào rootfs tại: \(rootfsURL.path)")
        
        guard let enumerator = fileManager.enumerator(
            at: cydiaPayloadURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [],
            errorHandler: { url, error -> Bool in
                print("[Podium-Cydia] Lỗi đọc file tại \(url.path): \(error)")
                return true
            }
        ) else { return }
        
        for case let sourceURL as URL in enumerator {
            let relativePath = sourceURL.path.replacingOccurrences(of: cydiaPayloadURL.path, with: "")
            let destinationURL = rootfsURL.appendingPathComponent(relativePath)
            
            do {
                let resourceValues = try sourceURL.resourceValues(forKeys: [.isDirectoryKey])
                if resourceValues.isDirectory == true {
                    if !fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true, attributes: nil)
                    }
                } else {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: sourceURL, to: destinationURL)
                    
                    // Cấp quyền thực thi (755) cho các binary của Cydia và dpkg/apt
                    if relativePath.contains("/Applications/Cydia.app/") || relativePath.contains("/bin/") || relativePath.contains("/sbin/") {
                        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)
                    }
                }
            } catch {
                print("[Podium-Cydia] Lỗi khi chép \(relativePath): \(error)")
            }
        }
        
        print("[Podium-Cydia] Hoàn tất nhúng Cydia vào máy ảo iOS 6!")
    }
}