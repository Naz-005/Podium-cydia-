import Foundation

public class RootFilesystemPreparer {
    
    // Cung cấp cả dạng instance lẫn static để tương thích tuyệt đối với mọi lời gọi trong Podium
    public var directoryURL: URL
    
    public init(directoryURL: URL) {
        self.directoryURL = directoryURL
    }
    
    public func userImageURL() throws -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    public static func userImageURL(in directoryURL: URL) throws -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    public static func installIPAs(urls: [URL], to imageURL: URL, stagingDirectory: URL) throws {
        // Logic cài đặt IPA rỗng an toàn
    }
    
    public static func readHFSPlusVolumeHeader(at imageURL: URL) throws -> Any {
        return "HFSPlusHeader"
    }
    
    public static func prepareUserImage(forFirmwareAt firmwareURL: URL, erasing: Bool, in directoryURL: URL) throws -> (url: URL, fromOldRecipe: Bool) {
        let fileManager = FileManager.default
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        if !fileManager.fileExists(atPath: tempURL.path) {
            try? fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true, attributes: nil)
            fileManager.createFile(atPath: tempURL.path, contents: nil, attributes: nil)
        }
        return (url: tempURL, fromOldRecipe: false)
    }
    
    public func prepareUserImage(forFirmwareAt firmwareURL: URL, erasing: Bool) throws -> (url: URL, fromOldRecipe: Bool) {
        let fileManager = FileManager.default
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        if !fileManager.fileExists(atPath: tempURL.path) {
            try? fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true, attributes: nil)
            fileManager.createFile(atPath: tempURL.path, contents: nil, attributes: nil)
        }
        return (url: tempURL, fromOldRecipe: false)
    }
    
    // --- HÀM NHÚNG CYDIA VÀO HỆ THỐNG FILE CỦA MÁY ẢO ---
    
    public static func injectCydiaIntoRootfs(rootfsURL: URL) {
        let fileManager = FileManager.default
        
        guard let cydiaPayloadURL = Bundle.main.resourceURL?.appendingPathComponent("CydiaRootfs"),
              fileManager.fileExists(atPath: cydiaPayloadURL.path) else {
            print("[Podium-Cydia] Không tìm thấy thư mục CydiaRootfs trong app bundle.")
            return
        }
        
        print("[Podium-Cydia] Bắt đầu chép Cydia vào rootfs tại: \(rootfsURL.path)")
        
        guard let enumerator = fileManager.enumerator(
            at: cydiaPayloadURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [],
            errorHandler: { _, _ in return true }
        ) else { return }
        
        for case let sourceURL as URL in enumerator {
            let relativePath = sourceURL.path.replacingOccurrences(of: cydiaPayloadURL.path, with: "")
            let destinationURL = rootfsURL.appendingPathComponent(relativePath)
            
            do {
                let resourceValues = try sourceURL.resourceValues(forKeys: [.isDirectoryKey])
                if resourceValues.isDirectory == true {
                    if !fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true, attributes: nil)
                    }
                } else {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: sourceURL, to: destinationURL)
                    
                    if relativePath.contains("/Applications/Cydia.app/") || relativePath.contains("/bin/") || relativePath.contains("/sbin/") {
                        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)
                    }
                }
            } catch {
                print("[Podium-Cydia] Lỗi khi chép \(relativePath): \(error)")
            }
        }
        print("[Podium-Cydia] Hoàn tất nhúng Cydia vào máy ảo iOS 6!")
    }
}