import Foundation

/// The 16 ARM data-processing opcodes, numbered exactly as the ARM ARM's
/// bits[24:21] opcode field, so `DataProcessingOp(rawValue:)` maps
/// straight from the encoding with no translation table.
enum DataProcessingOp: UInt8 {
    case and = 0b0000
    case eor = 0b0001
    case sub = 0b0010
    case rsb = 0b0011
    case add = 0b0100
    case adc = 0b0101
    case sbc = 0b0110
    case rsc = 0b0111
    case tst = 0b1000
    case teq = 0b1001
    case cmp = 0b1010
    case cmn = 0b1011
    case orr = 0b1100
    case mov = 0b1101
    case bic = 0b1110
    case mvn = 0b1111

    /// TST/TEQ/CMP/CMN only ever compute flags, never write a result.
    var isComparison: Bool {
        switch self {
        case .tst, .teq, .cmp, .cmn: return true
        default: return false
        }
    }

    /// MOV/MVN ignore Rn entirely — there's no first operand.
    var usesRn: Bool {
        switch self {
        case .mov, .mvn: return false
        default: return true
        }
    }

    /// Logical ops take carry-out straight from the barrel shifter and
    /// leave V (overflow) untouched; arithmetic ops compute both from the
    /// ALU add/subtract itself. This distinction is straight from the ARM
    /// ARM's data-processing flag-setting rules.
    var isLogical: Bool {
        switch self {
        case .and, .eor, .orr, .bic, .mov, .mvn, .tst, .teq: return true
        case .sub, .rsb, .add, .adc, .sbc, .rsc, .cmp, .cmn: return false
        }
    }
}

struct DataProcessingInstruction {
    let condition: ARMCondition
    let op: DataProcessingOp
    let setFlags: Bool
    let rn: Int
    let rd: Int
    let operand2: ShifterOperand
}

struct BranchInstruction {
    let condition: ARMCondition
    let link: Bool
    /// Signed byte offset, already sign-extended and ×4 from the raw
    /// 24-bit field. The branch target is this added to the *instruction
    /// address + 8* (`Registers.pcForOperandRead`), per the ARM ARM.
    let signedOffset: Int32
}

/// `BLX <label>` (immediate form — always lives in the unconditional-
/// instruction-extension space, so there's no real condition to carry,
/// unlike `BranchInstruction`): branches with link, *always* switching
/// to Thumb state — the mirror image of Thumb state's own `BLX`
/// (immediate), which always switches to ARM (see
/// `ThumbBranchLinkInstruction`). Fully executable now that
/// `ARMv7CPU+Thumb.swift` provides a real Thumb decoder to switch into
/// (see `ARMv7CPU.executeBranchLinkExchangeImmediate`).
struct BranchLinkExchangeImmediateInstruction: Equatable {
    /// Signed byte offset from the instruction address + 8, same
    /// convention as `BranchInstruction.signedOffset`.
    let signedOffset: Int32
}

/// `BX Rm`: branches to the address in `Rm`, and — on real hardware —
/// switches to Thumb state if `Rm`'s bit 0 is set (that's the whole
/// point of the name: Branch and *Exchange* instruction sets). Fully
/// executable — see `ARMv7CPU.executeBranchExchange` — now that a real
/// Thumb decoder exists to switch into. `link` covers `BLX` (register)
/// too — identical encoding (`0x12FFF3` vs plain `BX`'s `0x12FFF1`,
/// differing only in bits[7:4]) with `LR` additionally set to the
/// return address, verified against a real `blx r0` word from the
/// actual kernel.
struct BranchExchangeInstruction: Equatable {
    let condition: ARMCondition
    let link: Bool
    let rm: Int
}

/// A load/store's address offset — either a plain immediate, or a
/// (possibly shifted) register, reusing the exact same shift encoding
/// data-processing's register operand2 uses (bits[11:4] mean the same
/// thing in both instruction families).
enum LoadStoreOffset: Equatable {
    case immediate(UInt32)
    case register(rm: Int, shiftType: ShiftType, shiftAmount: UInt8)
}

struct LoadStoreInstruction {
    let condition: ARMCondition
    let isLoad: Bool
    let isByte: Bool
    let preIndexed: Bool
    let addOffset: Bool
    let writeback: Bool
    let rn: Int
    let rd: Int
    let offset: LoadStoreOffset
}

/// `LDM`/`STM` (block data transfer): moves a contiguous run of words
/// between memory and every register named in `registerList`, in
/// ascending register-number order regardless of `addOffset`/
/// `preIndexed` (which only choose where in memory that ascending run
/// starts — see `ARMv7CPU.executeBlockDataTransfer`).
///
/// `userRegisters` is the `S` bit (`^`): without PC in a load's list, it
/// transfers the User-mode bank instead of the current mode's (XNU saves
/// and restores a user thread's registers this way — `stm sp, {r0-lr}^`
/// on every exception from user mode); `LDM` with PC in the list is an
/// exception return instead, restoring CPSR from SPSR.
struct BlockDataTransferInstruction: Equatable {
    let condition: ARMCondition
    let isLoad: Bool
    let preIndexed: Bool
    let addOffset: Bool
    let writeback: Bool
    let rn: Int
    /// Bit *i* set means register *i* is included in the transfer.
    let registerList: UInt16
    var userRegisters = false
}

/// `SVC #imm` (formerly `SWI`): the Supervisor Call exception — how user
/// space makes system calls (`svc #0x80` in both instruction sets). The
/// immediate is only for the handler, which reads it from the instruction.
struct SupervisorCallInstruction: Equatable {
    let condition: ARMCondition
    let immediate: UInt32
}

/// `SRS{DA,IA,DB,IB} SP{!}, #mode`: stores the current mode's LR and SPSR
/// to the stack of `mode` (ARM DDI 0406C B9.3.16). `increment`/`before`
/// are the U and P bits of the addressing mode.
struct StoreReturnStateInstruction: Equatable {
    let increment: Bool
    let before: Bool
    let writeback: Bool
    let mode: UInt32
}

/// `RFE{DA,IA,DB,IB} Rn{!}`: loads PC and CPSR from two consecutive words
/// at `Rn` (B9.3.13) — the return path paired with `SRS`.
struct ReturnFromExceptionInstruction: Equatable {
    let increment: Bool
    let before: Bool
    let writeback: Bool
    let rn: Int
}

/// The three "extra load/store" transfer widths/signednesses — `STRH`
/// only ever uses `.unsignedHalfword` (there's no such thing as a signed
/// *store* — sign only matters when a narrower value is widened back
/// into a 32-bit register on load).
enum HalfwordTransferKind: Equatable {
    case unsignedHalfword
    case signedByte
    case signedHalfword
}

/// The "extra load/store" instructions' addressing offset — always a
/// plain (unshifted) register or an 8-bit immediate, unlike ordinary
/// load/store's register offset, which allows a shift.
enum HalfwordTransferOffset: Equatable {
    case immediate(UInt32)
    case register(Int)
}

/// `LDRH`/`STRH`/`LDRSB`/`LDRSH`: ARM's "extra load/store" instructions,
/// a structurally distinct encoding from ordinary single-register
/// load/store (see `ARMDecoder`'s doc comment on the bit4/bit7 check
/// that identifies this space) despite sharing the same top-level
/// instruction-class bits.
struct HalfwordDataTransferInstruction: Equatable {
    let condition: ARMCondition
    let isLoad: Bool
    let kind: HalfwordTransferKind
    let preIndexed: Bool
    let addOffset: Bool
    let writeback: Bool
    let rn: Int
    let rd: Int
    let offset: HalfwordTransferOffset
}

/// `LDRD`/`STRD` (ARM state): transfers `Rt`/`Rt+1` to/from consecutive
/// words at `[Rn, #offset]` — a different encoding from Thumb's
/// `ThumbLoadStoreDualInstruction`, sharing this decoder's "extra
/// load/store" bit4/bit7 gate with `HalfwordDataTransferInstruction`,
/// but a genuine architectural quirk of that shared space: with
/// `bit20 (L) == 0`, `SH == 10` means `LDRD` (a *load*, despite `L`
/// being clear) and `SH == 11` means `STRD`, rather than following the
/// normal L-bit convention `LDRH`/`STRH`/`LDRSB`/`LDRSH` use. Verified
/// against a real `ldrd r0, r1, [r0]` word from the actual kernel.
struct LoadStoreDualInstruction: Equatable {
    let condition: ARMCondition
    let isLoad: Bool
    let preIndexed: Bool
    let addOffset: Bool
    let writeback: Bool
    let rn: Int
    let rt: Int
    let offset: HalfwordTransferOffset
}

/// `MRS Rd, CPSR`/`MRS Rd, SPSR` (`isSPSR`, the R bit): reads the whole
/// CPSR, or the current mode's banked SPSR, into a register. Real
/// hardware calls SPSR access UNPREDICTABLE in User/System mode (no
/// SPSR exists there) — see `ARMv7CPU.executeMoveFromStatusRegister`.
struct MRSInstruction: Equatable {
    let condition: ARMCondition
    let isSPSR: Bool
    let rd: Int
}

enum MSRSource: Equatable {
    case register(Int)
    /// Already resolved at decode time, same as data-processing's
    /// immediate operand2 — a rotated 8-bit constant needs nothing from
    /// register state to compute.
    case immediate(UInt32)
}

/// `MSR CPSR_<fields>, Rm`/`#imm` or `MSR SPSR_<fields>, ...` (`isSPSR`,
/// the R bit): writes selected *bytes* of the CPSR, or of the current
/// mode's banked SPSR. `fieldMask` bit0=c(control, bits[7:0]),
/// bit1=x(extension, [15:8]), bit2=s(status, [23:16]), bit3=f(flags,
/// [31:24]) — the same order and meaning as the real mask field, so it
/// can be used directly to build a byte-granular write mask at execute
/// time.
struct MSRInstruction: Equatable {
    let condition: ARMCondition
    let isSPSR: Bool
    let fieldMask: UInt8
    let source: MSRSource
}

/// `MOVW`/`MOVT` (ARMv6T2+): load a 16-bit immediate into a register's
/// low or high half, the other half left alone (`MOVT`) or zeroed
/// (`MOVW`). Distinct from classic data-processing `MOV` — no rotation,
/// no shifter carry-out, any 16-bit value representable directly.
struct MovWideInstruction: Equatable {
    let condition: ARMCondition
    let isTop: Bool
    let rd: Int
    let imm16: UInt16
}

/// `MCR`/`MRC`: transfers one 32-bit value between an ARM register and a
/// coprocessor register, identified by (coprocessor, opc1, CRn, CRm,
/// opc2) — there's no ALU operation or flag effect, just the transfer.
///
/// Podium models this as a real, addressable register file (`CP15State`)
/// rather than refusing every coprocessor instruction outright, but does
/// **not** implement the hardware behavior CP15 registers are actually
/// for — cache maintenance, MMU/TLB control, and so on. A write here is
/// honestly just "the guest wrote this value to this coprocessor
/// register slot", not "Podium invalidated a cache" or "the MMU
/// reconfigured itself". See `CP15State`'s own doc comment.
struct CoprocessorRegisterTransferInstruction: Equatable {
    let condition: ARMCondition
    let isLoad: Bool // MRC (coprocessor -> ARM register) vs MCR (ARM register -> coprocessor)
    let coprocessor: Int
    let opc1: Int
    let rt: Int
    let crn: Int
    let crm: Int
    let opc2: Int
}

/// `CPS`: sets or clears the CPSR's interrupt/abort mask bits directly —
/// always unconditional (it lives in ARM's "unconditional instruction
/// extension" space, not the normal conditional encoding, hence no
/// `ARMCondition` here).
struct ChangeProcessorStateInstruction: Equatable {
    let enable: Bool
    let affectsAbort: Bool
    let affectsIRQ: Bool
    let affectsFIQ: Bool
    /// Whether this `CPS` also carries a mode change (the `mmod`/`M` bit,
    /// bit17) — independent of `enable`/`affectsXxx`: real ARM boot code's
    /// standard per-mode-stack-setup idiom (`CPS #<mode>` with no `IE`/`ID`
    /// prefix, `imod==0b00`) changes *only* mode, touching no mask bits at
    /// all.
    let changesMode: Bool
    let mode: UInt32
}

/// `UQSUB8 Rd, Rn, Rm`: four parallel unsigned 8-bit saturating
/// subtractions (`Rd.byte[i] = max(0, Rn.byte[i] - Rm.byte[i])`), one of
/// ARMv6's "media instructions" (parallel addition/subtraction) —
/// verified via Capstone against a real word from the actual kernel.
/// Only this one instruction from that whole extension space is
/// decoded; the rest (dozens of signed/unsigned ×
/// simple/saturating/halving × ADD16/ASX/SAX/SUB16/ADD8/SUB8
/// combinations, plus SEL/USAD8/PKH/REV/SSAT/USAT/SXTB and friends,
/// which all share this same bit4==1 space) stay `.unsupported` until a
/// real word confirms one is needed. Doesn't affect any flags (unlike
/// the non-saturating `SUB8`, this doesn't set the GE bits either).
struct UQSub8Instruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rn: Int
    let rm: Int
}

/// `CLZ Rd, Rm`: counts leading zero bits (32 if `Rm` is zero). Lives in
/// the "miscellaneous instructions" region of the data-processing block
/// — the exact same top-level shape (`!setFlags && op.isComparison`)
/// `MRS`/`MSR` already decode from, disambiguated by the full
/// bits[27:20]/[19:16]/[11:4] pattern rather than the `op`/`S` fields
/// alone, which aren't enough on their own to tell them apart. Verified
/// against a real word from the actual kernel via Capstone.
struct ClzInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rm: Int
}

/// `LDREX Rt, [Rn]`: a word load that also opens the local exclusive
/// monitor on `[Rn]` for a later `STREX` to check (see
/// `ARMv7CPU.exclusiveMonitorAddress`). Lives in
/// the "synchronization primitives" space, sharing the multiply/extra-
/// load-store gate's `!I && bit7 && bit4` shape with `SH == 0` (the
/// other three `SH` values are the halfword/signed-byte transfers
/// already decoded there); disambiguated by the full bits[27:20]/
/// [11:8]/[3:0] pattern, verified against a real `ldrex r0, [ip]` word
/// from the actual kernel.
/// ARM-state multiply and multiply-accumulate (ARM DDI 0406C A5.2.5):
/// bits[27:24] == 0000 and bits[7:4] == 1001, with the operation in
/// bits[23:20] — the same `!I && bit7 && bit4 && SH == 00` space the
/// synchronization primitives (`LDREX`/`STREX`) share, told apart by
/// bits[27:24]. The 32-bit forms write `rd`; the long (64-bit) forms
/// write `rd` as RdHi and `ra` as RdLo, which are also their accumulator
/// for `UMLAL`/`SMLAL`/`UMAAL`. With `setFlags`, N and Z come from the
/// (32- or 64-bit) result and C/V are left alone (ARMv6 and later).
/// Verified against real `mul r0, r3, r4` and `umlal r4, ip, lr, r3`
/// words from the actual kernel.
struct MultiplyInstruction: Equatable {
    enum Kind: Equatable {
        case mul, mla, mls
        case umull, umlal, smull, smlal, umaal

        var isLong: Bool {
            switch self {
            case .mul, .mla, .mls: return false
            case .umull, .umlal, .smull, .smlal, .umaal: return true
            }
        }
    }

    let condition: ARMCondition
    let kind: Kind
    let setFlags: Bool
    let rd: Int
    let ra: Int
    let rm: Int
    let rs: Int
}

/// `LDREX{B,H} Rt, [Rn{, #offset}]`: loads and opens the exclusive
/// monitor on the address. `size` is 1, 2 or 4 bytes (zero-extended); the
/// offset exists only in Thumb-2's word form (`imm8 * 4`), the ARM forms
/// and the Thumb byte/halfword forms have none.
struct LoadExclusiveInstruction: Equatable {
    let condition: ARMCondition
    let rt: Int
    let rn: Int
    var size = 4
    var offset: UInt32 = 0
}

/// `LDREXD Rt, Rt2, [Rn]`: loads a 64-bit value into the register pair
/// `Rt:Rt2` (`Rt2 == Rt+1`, always — real hardware requires `Rt` even and
/// rejects an odd `Rt` as unpredictable, so `Rt2` isn't a separately
/// decoded field). Opens the exclusive monitor exactly like
/// `LoadExclusiveInstruction`. Verified against a real `ldrexd r4, r5, [r2]`
/// word from the actual kernel — distinguished from plain `LDREX` by
/// bit[21] of the opcode (`0b101` vs `0b100` in bits[23:21]).
///
/// Thumb-2's `LDREXD` names `Rt2` separately (any register), so it's a
/// field; the ARM decoder fills in `Rt + 1`.
struct LoadExclusiveDoubleInstruction: Equatable {
    let condition: ARMCondition
    let rt: Int
    let rt2: Int
    let rn: Int
}

/// `STREX Rd, Rt, [Rn]`: stores `Rt` to `[Rn]` and sets `Rd` to the
/// exclusive-access status (`0` success, `1` fail). It succeeds only if
/// the monitor a prior `LDREX` opened on `[Rn]` is still open — an
/// interrupt handler's own exclusive access or `CLREX` in between closes
/// it, and the store then doesn't happen. Verified against a real `strex r3, r0, [ip]` word from the
/// actual kernel, sharing `LoadExclusiveInstruction`'s decode gate.
/// `size` and `offset` as in `LoadExclusiveInstruction`.
struct StoreExclusiveInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rt: Int
    let rn: Int
    var size = 4
    var offset: UInt32 = 0
}

/// `STREXD Rd, Rt, Rt2, [Rn]`: stores the register pair `Rt:Rt2`
/// (`Rt2 == Rt+1`, always — same constraint as `LDREXD`) as a 64-bit
/// value to `[Rn]` and sets `Rd` to the exclusive-access status, with
/// the same monitor check as `StoreExclusiveInstruction`. Verified against a real
/// `strexd r3, r8, sb, [r2]` word from the actual kernel — distinguished
/// from plain `STREX` by bit[21] of the opcode, the same as
/// `LoadExclusiveDoubleInstruction` vs `LoadExclusiveInstruction`.
/// `rt2` as in `LoadExclusiveDoubleInstruction`.
struct StoreExclusiveDoubleInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rt: Int
    let rt2: Int
    let rn: Int
}

/// `REV Rd, Rm`: reverses the byte order of a word (`Rd.byte[i] =
/// Rm.byte[3-i]`) — also lives in the media-instructions space (a
/// unary sibling of `UQSUB8`, hence no `Rn`), verified against a real
/// word from the actual kernel via Capstone. `REV16`/`REVSH` (halfword
/// and signed-halfword variants sharing this same top-level shape)
/// aren't decoded yet.
struct RevInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rm: Int
}

/// `BFI Rd, Rn, #lsb, #width` / `BFC Rd, #lsb, #width` (ARM state):
/// copies `width` low bits of `Rn` into `Rd` starting at bit `lsb`,
/// leaving the rest of `Rd` untouched — `BFC` is the same encoding with
/// `Rn == 1111` (no source register field is actually read; those bits
/// are architecturally just cleared to zero, not filled with `R15`'s
/// value, hence `sourceRegister: nil` rather than `15`). Not part of
/// ARMv6's other "media instructions" (parallel add/sub, `REV`) but
/// shares that same bits[27:25]==011,bit4==1 decode gate — bits[27:21]
/// == `0b0111110` (`SBFX`'s sibling at `0b0111101`/`0b0111010` isn't
/// decoded). `width = msb - lsb + 1`, where `msb`/`lsb` are the real
/// word's own field names. Verified against a real `bfi r0, r2, #0x10,
/// #4` word from the actual kernel. Doesn't affect flags.
struct BitFieldInsertInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let sourceRegister: Int?
    let lsb: Int
    let width: Int
}

/// `UBFX Rd, Rn, #lsb, #width` (ARM state): unsigned bit-field extract —
/// this is a *different* encoding from Thumb-2's `UBFX`/`SBFX`
/// (`ThumbBitFieldExtractInstruction`), sharing ARM state's "media instructions"
/// bits[27:25]==011,bit4==1 gate with `BFI`/`BFC`/`REV`/`UQSUB8` rather
/// than Thumb's "data-processing plain binary immediate" space. Keyed
/// on bits[27:21] == `0b0111111` (one more than `BFI`/`BFC`'s
/// `0b0111110`) and bits[6:4] == `0b101`. `width = widthm1 + 1`.
/// Verified against a real `ubfx r3, r0, #3, #0xa` word from the actual
/// kernel. Doesn't affect flags.
struct BitFieldExtractInstruction: Equatable {
    let condition: ARMCondition
    let rd: Int
    let rn: Int
    let lsb: Int
    let width: Int
}

/// Advanced SIMD "one register and a modified immediate" (ARM DDI 0406C
/// A7.4.6): `VMOV`/`VMVN`/`VORR`/`VBIC` (immediate), every `cmode`, `D`
/// and `Q` forms. `imm64` is already expanded (`AdvSIMDExpandImm`); `vd`
/// is a `D` register number (the first of the pair for `Q`).
struct NEONModifiedImmediateInstruction: Equatable {
    enum Operation: Equatable { case move, moveNot, orr, bic }
    let operation: Operation
    let vd: Int
    let isQuad: Bool
    let imm64: UInt64
}

/// `VEOR` (NEON bitwise exclusive-OR), `Dd = Dn ^ Dm` (or the `Q`-register
/// equivalent). Shares the "three registers of the same length" shape
/// with `VRSHL` but from the family's "bitwise operations" sub-space:
/// opc(bits[11:8])==0b0001 with size(bits[21:20])==0b00 and U(bit24)==1
/// selects `VEOR` specifically out of that sub-space's `VAND`/`VBIC`/
/// `VORR`/`VORN`/`VEOR`/`VBSL`/`VBIT`/`VBIF` siblings — confirmed against
/// a real `veor q14, q14, q14` word from the actual kernel (a common
/// register-zeroing idiom) via Capstone. Unlike `VRSHL`, this is the
/// first NEON instruction needing `Q` (128-bit, `Q`==bit6==1) width:
/// `vd`/`vn`/`vm` are `Q`-register indices when `isQuad` is set (real
/// hardware requires the underlying 5-bit `D`-register field's low bit
/// be 0 in that case, and defines `Qn` as the pair `D[2n]`:`D[2n+1]`),
/// `D`-register indices otherwise.
struct VEORInstruction: Equatable {
    let vd: Int
    let vn: Int
    let vm: Int
    let isQuad: Bool
}

/// `VADD.I<size>` (NEON integer add), `Qd = Qn + Qm` per lane (or the `D`
/// equivalent). Shares the "three registers of the same length" shape
/// with `VRSHL`/`VEOR`/`VORR` but from the "integer add/subtract" opc
/// (bits[11:8]==0b1000; `U`(bit24)==0 selects add, ==1 would select
/// `VSUB`, not decoded). Unlike `VRSHL`, this one is needed at `Q`
/// (128-bit) width — confirmed against a real `vadd.i32 q12, q4, q15`
/// word from the actual kernel.
struct VADDInstruction: Equatable {
    enum ElementSize: UInt8 {
        case bits8 = 0, bits16 = 1, bits32 = 2, bits64 = 3
    }

    let size: ElementSize
    let vd: Int
    let vn: Int
    let vm: Int
    let isQuad: Bool
}

/// `VORR` (NEON bitwise OR, register form), `Dd = Dn | Dm` (or the `Q`
/// equivalent) — real code's `VORR Qd, Qn, Qn` idiom is also how `VMOV`
/// (register) is encoded for `Q`/`D` registers (no dedicated encoding
/// exists; `Vn==Vm` is simply the identity case of a bitwise OR). Shares
/// `VEOR`'s "bitwise operations" sub-space (opc==0b0001) but with
/// size(bits[21:20])==0b10 and `U`(bit24)==0 selecting `VORR`
/// specifically out of that sub-space's `VAND`/`VBIC`/`VORR`/`VORN`
/// (`U`==0) siblings — confirmed against a real `vorr q8, q12, q12` word
/// from the actual kernel via Capstone.
struct VORRInstruction: Equatable {
    let vd: Int
    let vn: Int
    let vm: Int
    let isQuad: Bool
}

/// `VEXT`: extracts `registerBytes` (8 for `D`, 16 for `Q`) consecutive
/// bytes starting at byte offset `byteOffset` from the logical
/// concatenation of `Vn` (low) followed by `Vm` (high) — ARM DDI 0406C
/// A8.8.111. The assembly's `.8`/`.16`/`.32`/`.64` "size" suffix is
/// purely a display convenience: the encoded `imm4` field is always a
/// raw byte count, confirmed empirically against two real kernel words
/// (`vext.64 q8, q4, q11, #1` -> imm4=8, `vext.32 q12, q9, q14, #1` ->
/// imm4=4 — the assembly-displayed `#1` means "1 element", but the byte
/// offset scales with element size, so this codebase only needs to track
/// the already-resolved byte offset, not the element size itself).
struct VEXTInstruction: Equatable {
    let vd: Int
    let vn: Int
    let vm: Int
    let isQuad: Bool
    let byteOffset: Int
}

/// `VSHL`/`VSHR` (immediate). Shares the "two registers and a shift
/// amount" NEON space; `opc`(bits[11:8])==0b0101 with `U`(bit24)==0
/// selects `VSHL` (left, non-saturating, non-inserting), `opc`==0b0000
/// selects `VSHR` (right, arithmetic when `U`==0, logical when `U`==1).
/// The encoded `imm6` field packs both the element size and the shift
/// amount together: the position of its highest set bit selects the
/// element size (bit5→32-bit, bit4→16-bit, bit3→8-bit; the 64-bit case
/// uses a different encoding entirely and isn't decoded), and the
/// remaining bits give the shift amount — `imm6 - size` for a left
/// shift, `2*size - imm6` for a right shift (already resolved into
/// `shiftAmount` at decode time, not carried as raw `imm6`). Verified
/// against two real kernel words: `vshl.i32 q12, q8, #1` (imm6=33 ->
/// size=32, left-shift 1) and `vshr.u32 q8, q8, #0x1f` (imm6=33 ->
/// size=32, right-shift 31) — the shared size-decoding logic makes both
/// self-consistent, not two independent guesses.
struct VectorShiftImmediateInstruction: Equatable {
    enum Direction {
        case left, right
    }

    let direction: Direction
    let unsigned: Bool
    let elementBits: Int
    let shiftAmount: Int
    let vd: Int
    let vm: Int
    let isQuad: Bool
}

/// `VREV16`/`VREV32`/`VREV64`: reverses the order of `elementBits`-wide
/// elements within each `groupSize`-wide group of a `D` or `Q` register.
/// From NEON's "two registers, miscellaneous" space — bits[8:7] (`op`)
/// select the group size (`00`→64-bit, `01`→32-bit, `10`→16-bit) and
/// bits[19:18] (`size`) select the element width being reversed within
/// each group (`00`→8-bit, `01`→16-bit, `10`→32-bit). Verified against a
/// real `vrev32.8 q4, q12` word from the actual kernel (op=01→32-bit
/// groups, size=00→8-bit elements, Q=1→128-bit width).
struct VREVInstruction: Equatable {
    enum GroupSize: UInt8 {
        case bits64 = 0, bits32 = 1, bits16 = 2
    }

    let groupSize: GroupSize
    let elementBits: Int
    let vd: Int
    let vm: Int
    let isQuad: Bool
}

/// `VLD1`/`VST1` ("multiple single elements"): loads/stores 1, 2, 3, or 4
/// consecutive `D` registers as raw bytes from/to memory at `[Rn]`, with
/// optional post-increment writeback. Since this is the "single
/// elements" (not "single lane" or "all lanes") form, the `size` field
/// only ever affects alignment checking (not modeled) — no deinterleave/
/// reorder happens regardless of element size, so each `D` register is
/// just its 8 raw memory bytes in address order, exactly like the `LDRD`/
/// `STRD`/`LDREXD`/`STREXD` low-word-then-high-word convention elsewhere
/// in this codebase. Verified against a real `vld1.32 {d30,d31},
/// [r3:0x80]!` word from the actual kernel: bits[11:8] (`type`)==0b1010
/// selects a 2-register list (the full 1/2/3/4 → 0b0111/0b1010/0b0110/
/// 0b0010 table is ARM's own fixed mapping, not a guess); `Rm`==0b1101 is
/// the real, spec-defined "add the transfer size" writeback idiom (the
/// plain `!` with no explicit offset register) — distinct from `Rm`==
/// 0b1111 (no writeback) and any other value (an explicit offset
/// register).
struct ElementLoadStoreInstruction: Equatable {
    enum Writeback: Equatable {
        case none
        case byTransferSize
        case register(Int)
    }

    let isLoad: Bool
    let rn: Int
    /// `Dd`: the first (lowest-numbered) `D` register transferred.
    let firstRegister: Int
    let registerCount: Int
    let writeback: Writeback
}

/// VFP/NEON extension-register load/store (ARM DDI 0406C A7.6): `VLDR`/
/// `VSTR` (one register at `Rn ± imm8*4`), and `VLDM`/`VSTM` increment-
/// after (optional writeback) or decrement-before (writeback; `VPUSH`/
/// `VPOP` when `Rn` is SP), for single- (`S`) or double-precision (`D`)
/// registers. Verified against real `vpush {d16-d31}`, `vstmia r2,
/// {d16, d17}` and `vstr d16, [sp, #8]` words from the actual kernel.
struct ExtensionRegisterLoadStoreInstruction: Equatable {
    enum Addressing: Equatable {
        case offset(UInt32, add: Bool)
        case incrementAfter(writeback: Bool)
        case decrementBefore
    }
    let condition: ARMCondition
    let isLoad: Bool
    let isDouble: Bool
    let rn: Int
    /// The first register transferred: a `D` index when `isDouble`,
    /// otherwise an `S` index.
    let firstRegister: Int
    let registerCount: Int
    /// Words the whole transfer spans — for multiples this is `imm8`
    /// itself, including the extra word of the legacy odd-`imm8`
    /// (`FLDMX`/`FSTMX`) form, so writeback moves `Rn` exactly as far as
    /// hardware would.
    let wordCount: Int
    let addressing: Addressing
}

/// `VMOV` between two core registers and one `D` register, or two
/// consecutive `S` registers (ARM DDI 0406C A7.8, "64-bit transfers").
/// `toCore` is the `op`/L bit: extension register(s) -> `Rt`/`Rt2`.
struct VFPTwoRegisterTransferInstruction: Equatable {
    let condition: ARMCondition
    let toCore: Bool
    let isDouble: Bool
    let rt: Int
    let rt2: Int
    /// A `D` index when `isDouble`, otherwise the first of two `S` indices.
    let extensionRegister: Int
}

/// The architectural hints (ARM DDI 0406C A8.8.x), numbered by the hint
/// field both instruction sets share.
enum ProcessorHint: UInt16, Equatable {
    case nop = 0
    case yield = 1
    case waitForEvent = 2
    case waitForInterrupt = 3
    case sendEvent = 4
}

/// `NOP`/`YIELD`/`WFE`/`WFI`/`SEV` (ARM state): the `MSR` (immediate)
/// encoding with an empty field mask and `R == 0` (ARM DDI 0406C A5.2.11).
/// Decoded apart from `MSR` because executing one as an `MSR` that writes
/// nothing silently drops the `WFI` — real `cpu_idle_wfi` is ARM code
/// (`dsb sy; wfi` at `0x80088C48`), so the idle loop never let virtual
/// time skip ahead and an idle kernel cost as much host time as a busy one.
struct HintInstruction: Equatable {
    let condition: ARMCondition
    let hint: ProcessorHint
}

enum ARMInstruction: Equatable {
    case dataProcessing(DataProcessingInstruction)
    case branch(BranchInstruction)
    case branchExchange(BranchExchangeInstruction)
    case branchLinkExchangeImmediate(BranchLinkExchangeImmediateInstruction)
    case blockDataTransfer(BlockDataTransferInstruction)
    case halfwordDataTransfer(HalfwordDataTransferInstruction)
    case loadStoreDual(LoadStoreDualInstruction)
    case loadStore(LoadStoreInstruction)
    case movWide(MovWideInstruction)
    case moveFromStatusRegister(MRSInstruction)
    case moveToStatusRegister(MSRInstruction)
    case coprocessorRegisterTransfer(CoprocessorRegisterTransferInstruction)
    case changeProcessorState(ChangeProcessorStateInstruction)
    case uqsub8(UQSub8Instruction)
    case bitFieldInsert(BitFieldInsertInstruction)
    case bitFieldExtract(BitFieldExtractInstruction)
    case multiply(MultiplyInstruction)
    case rev(RevInstruction)
    case clz(ClzInstruction)
    case loadExclusive(LoadExclusiveInstruction)
    case storeExclusive(StoreExclusiveInstruction)
    case loadExclusiveDouble(LoadExclusiveDoubleInstruction)
    case storeExclusiveDouble(StoreExclusiveDoubleInstruction)
    case hint(HintInstruction)
    case supervisorCall(SupervisorCallInstruction)
    case storeReturnState(StoreReturnStateInstruction)
    case returnFromException(ReturnFromExceptionInstruction)
    /// `DSB`/`DMB`/`ISB` (memory/instruction ordering barriers) and
    /// `PLD` (immediate, a cache-prefetch hint). Podium's interpreter
    /// executes everything strictly in program order with no caching,
    /// reordering, or pipelining to synchronize or prefetch for — so for
    /// this CPU, correctly implementing any of these *is* treating them
    /// as a no-op, not a missing feature.
    case memoryBarrier
    /// `CLREX`: clears the local exclusive monitor, so a pending
    /// `STREX` fails. XNU runs it on exception entry.
    case clearExclusive
    case bitwiseExclusiveOr(VEORInstruction)
    case neonModifiedImmediate(NEONModifiedImmediateInstruction)
    case bitwiseOr(VORRInstruction)
    case integerAdd(VADDInstruction)
    case vectorExtract(VEXTInstruction)
    case vectorShiftImmediate(VectorShiftImmediateInstruction)
    case elementLoadStore(ElementLoadStoreInstruction)
    case reverseElements(VREVInstruction)
    case extensionRegisterLoadStore(ExtensionRegisterLoadStoreInstruction)
    case vfpTwoRegisterTransfer(VFPTwoRegisterTransferInstruction)
    case vfpDataProcessing(VFPDataProcessingInstruction)
    case neon(NEONInstruction)
    case media(MediaInstruction)
    case neonStructureLoadStore(NEONStructureLoadStoreInstruction)
    /// A recognized-but-not-yet-implemented instruction family: multiply
    /// and the "extra load/store" SWP/reserved encodings (SH==00), the
    /// `S`-bit form of block data transfer (see
    /// `BlockDataTransferInstruction`'s doc comment), register-shifted-
    /// by-register operand2, most of the coprocessor space (anything but
    /// MCR/MRC), SWI, most of the unconditional-instruction-extension
    /// space (anything but CPS and the DSB/DMB/ISB barriers), and all of
    /// NEON except `VRSHL` (`Q`-register width, and every other opcode in
    /// its "three registers of the same length" encoding family — VADD,
    /// VMUL, VAND, VMAX, dozens more — sharing that same bit shape).
    case unsupported(rawWord: UInt32)
    /// A genuinely undefined/reserved encoding.
    case undefined(rawWord: UInt32)
}

extension DataProcessingInstruction: Equatable {
    static func == (lhs: DataProcessingInstruction, rhs: DataProcessingInstruction) -> Bool {
        lhs.condition == rhs.condition && lhs.op == rhs.op && lhs.setFlags == rhs.setFlags
            && lhs.rn == rhs.rn && lhs.rd == rhs.rd && lhs.operand2 == rhs.operand2
    }
}

extension BranchInstruction: Equatable {}
extension LoadStoreInstruction: Equatable {}

extension ShifterOperand: Equatable {
    static func == (lhs: ShifterOperand, rhs: ShifterOperand) -> Bool {
        switch (lhs, rhs) {
        case (.immediate(let lv, let lc), .immediate(let rv, let rc)):
            return lv == rv && lc == rc
        case (.shiftedRegister(let lrm, let lst, let lsa), .shiftedRegister(let rrm, let rst, let rsa)):
            return lrm == rrm && lst == rst && lsa == rsa
        case (.shiftedRegisterByRegister(let lrm, let lst, let lrs), .shiftedRegisterByRegister(let rrm, let rst, let rrs)):
            return lrm == rrm && lst == rst && lrs == rrs
        default:
            return false
        }
    }
}
