import Foundation

public class RootFilesystemPreparer {
    
    public static func userImageURL(in directoryURL: URL) -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    public static func userImageURL(in directoryURL: URL) throws -> URL {
        return directoryURL.appendingPathComponent("user_image.img")
    }
    
    public static func installIPAs(urls: [URL], to imageURL: URL, stagingDirectory: URL) throws {}
    
    public static func readHFSPlusVolumeHeader(at imageURL: URL) throws -> HFSPlusVolumeHeader {
        let dummyBytes: [UInt8] = Array(repeating: 0, count: 512)
        return HFSPlusVolumeHeader(bytes: dummyBytes)
    }
    
    public static func prepareUserImage(forFirmwareAt firmwareURL: URL, erasing: Bool, in directoryURL: URL) throws -> (URL, Bool) {
        let fileManager = FileManager.default
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        if !fileManager.fileExists(atPath: tempURL.path) {
            try? fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true, attributes: nil)
            fileManager.createFile(atPath: tempURL.path, contents: nil, attributes: nil)
        }
        return (tempURL, false)
    }
    
    public static func prepareUserImage(firmwareURL: URL, erasing: Bool, in directoryURL: URL) throws -> (URL, Bool) {
        let tempURL = directoryURL.appendingPathComponent("user_image.img")
        return (tempURL, false)
    }
    
    // --- HÀM NHÚNG CYDIA VÀO HỆ THỐNG FILE CỦA MÁY ẢO ---
    
    public static func injectCydiaIntoRootfs(rootfsURL: URL) {
        let fileManager = FileManager.default
        guard let cydiaPayloadURL = Bundle.main.resourceURL?.appendingPathComponent("CydiaRootfs"),
              fileManager.fileExists(atPath: cydiaPayloadURL.path) else {
            return
        }
        
        let enumerator = fileManager.enumerator(at: cydiaPayloadURL, includingPropertiesForKeys: [.isDirectoryKey])
        while let sourceURL = enumerator?.nextObject() as? URL {
            let relativePath = sourceURL.path.replacingOccurrences(of: cydiaPayloadURL.path, with: "")
            let destinationURL = rootfsURL.appendingPathComponent(relativePath)
            do {
                if sourceURL.hasDirectoryPath {
                    if !fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true)
                    }
                } else {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: sourceURL, to: destinationURL)
                }
            } catch {}
        }
    }
}